#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/poll.h>
#include <linux/cdev.h>
#include <linux/ioctl.h>
#include <linux/sysfs.h>
#include <linux/kobject.h>

#define B_SIZE 20
#define MAX_DEV 1
#define MAGIC_VAR 'a'
#define RD_VAL _IOR(MAGIC_VAR, 1, char *)
#define WR_VAL _IOW(MAGIC_VAR, 2, char *)

volatile int myfile = 0;
int devno, mjr, mnr;

struct stuff {
	char buff[B_SIZE];
	struct cdev mycdev;
}kbuffer;


static int my_init(void);
static void my_exit(void);

static int myopen(struct inode *iinode, struct file *fle);
static int myclose(struct inode *iinode, struct file *fle);
static ssize_t mywrite(struct file *fle, const char *usr_buff,
		size_t len, loff_t *offset);
static ssize_t myread(struct file *fle, char *usr_buff,
		size_t len, loff_t *offset);
static long my_ioctl(struct file *fle, unsigned int cmd, 
		unsigned long arg);
static ssize_t sysfs_show(struct kobject *kobj, 
		struct kobj_attribute *myattr, char *buff);
static ssize_t sysfs_store(struct kobject *kobj, 
		struct kobj_attribute *myattr,
		const char *buff, size_t count);

struct kobject *my_kobj;

struct kobj_attribute my_kattr = __ATTR(myfile, 0660, sysfs_show, 
		sysfs_store);

const struct file_operations my_ops = {
	.owner = THIS_MODULE,
	.open  = myopen,
	.read  = myread,
	.write = mywrite,
	.unlocked_ioctl = my_ioctl,
	.release = myclose,
};

static int my_init(void)
{
	int retval;

	pr_info("my init function is invoked\n");

	retval = alloc_chrdev_region(&devno, 0, MAX_DEV,"mydriver");
	if (0 > retval) {
		pr_info("Registration of driver is failed\n");
		return -1;
	}
	pr_info("mjr = %d\nmnr = %d\n", mjr = MAJOR(devno),
			mnr = MINOR(devno));

	cdev_init(&kbuffer.mycdev,&my_ops);

	retval = cdev_add(&kbuffer.mycdev, devno, 1);
	if (0 > retval) {
		pr_info("failed to add cdev object to driver\n");
		return -2;
	}
	pr_info("added cdev object to driver\n");

	my_kobj = kobject_create_and_add("mysys_fldr", NULL);

	if (sysfs_create_file(my_kobj, &my_kattr.attr)) {
		pr_info("cannot create the file in sysfs\n");
		return -3;
	}
	pr_info("created the file in sysfs\n");
	
	pr_info("the module is inserted\n");

	return 0;
}

static void my_exit(void)
{
	pr_info("my exit func is invoked\n");

	sysfs_remove_file(my_kobj, &my_kattr.attr);
	pr_info("the file is removed from the sysfs folder");

	kobject_put(my_kobj);
	pr_info("The folder in sysfs is removed\n");

	cdev_del(&kbuffer.mycdev);
	pr_info("unlinkd the cdev object from driver\n");

	unregister_chrdev_region(devno, MAX_DEV);
	pr_info("unregistered the driver\n");

	return;
}

static int myopen(struct inode *iinode, struct file *fle)
{
	pr_info("%s func invoked\n", __func__);
	fle->private_data = &kbuffer;

	return 0;
}

static ssize_t mywrite(struct file *fle, const char *usr_buff,
		size_t len, loff_t *offset)
{
	pr_info("%s func invoked\n", __func__);

	return 0;
}

static ssize_t myread(struct file *fle, char *usr_buff,
		size_t len, loff_t *offset)
{
	pr_info("%s func invoked\n", __func__);

	return 0;
}

static long my_ioctl(struct file *fle, unsigned int cmd, 
		unsigned long int arg)
{
	int retval;
	pr_info("%s func invoked\n", __func__);

	switch (cmd) {
		case WR_VAL :
			retval = copy_from_user(kbuffer.buff,
				       	(char *)arg, B_SIZE);
			if (retval)
				pr_info("Err to write data\n");
			
			kbuffer.buff[B_SIZE] = '\0';
			pr_info("%s \n", kbuffer.buff);

			break;
		case RD_VAL :
			retval = copy_to_user((char *)arg, 
					kbuffer.buff, B_SIZE);
			if (retval)
				pr_info("erroe to read the data\n");
			pr_info("data sent");

			break;
	}
	return 0;
}



static int myclose(struct inode *iinode, struct file *fle)
{
	pr_info("%s func invoked\n", __func__);

	return 0;
}

static ssize_t sysfs_show(struct kobject *kobj,
                struct kobj_attribute *attr, char *buf)
{
        pr_info("Sysfs - Read!!!\n");
        return 0;
}

static ssize_t sysfs_store(struct kobject *kobj,
                struct kobj_attribute *attr,
		const char *buf, size_t count)
{
        pr_info("Sysfs - Write!!!\n");
        return count;
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("BALU");
