#include <stdio_ext.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>

#define MAGIC_VAL 'a'
#define RD_VAL _IOR(MAGIC_VAL, 1, char*)
#define WR_VAL _IOW(MAGIC_VAL, 2, char*)

#define EXIT 0
#define B_SIZE 20

int main()
{
	int fd, retval, option;
	char ptr[B_SIZE], str[B_SIZE];

	fd = open("/sys/mysys_fldr/myfile", O_RDWR);
	if (0 > retval) {
		printf("failed to open\n");
		return -1;
	}

	while (1) {
		printf(" 0 - exit \n 1 - read \n 2 - write \n"
				"select the option");
		__fpurge(stdin);
		scanf("%d", &option);
		
		if(EXIT == option)
			break;

		switch (option) {
			case 1:
				if (ioctl(fd, RD_VAL, (char*)str)) 
					printf("failed to read full data\n");
				str[B_SIZE] = '\0';
				printf("%s \n",str);

				break;
			case 2:
				printf("enter the msg to kernel :");
				__fpurge(stdin);
				scanf("%[^\n]", ptr);
				if (ioctl(fd, WR_VAL, (char *)ptr))
					printf("failed to write full data\n");
				break;
			default :
				printf("select valid option\n");
		}
	}
	write(fd, ptr, 1);
	read(fd, str, 1);
	close(fd);

	return 0;
}



